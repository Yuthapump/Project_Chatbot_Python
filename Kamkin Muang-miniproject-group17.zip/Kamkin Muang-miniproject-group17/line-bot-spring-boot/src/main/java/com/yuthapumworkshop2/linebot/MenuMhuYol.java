package com.yuthapumworkshop2.linebot;
import com.linecorp.bot.model.action.URIAction;
import com.linecorp.bot.model.message.FlexMessage;
import com.linecorp.bot.model.message.flex.component.*;
import com.linecorp.bot.model.message.flex.container.Bubble;
import com.linecorp.bot.model.message.flex.unit.FlexAlign;
import com.linecorp.bot.model.message.flex.unit.FlexFontSize;
import com.linecorp.bot.model.message.flex.unit.FlexLayout;
import com.linecorp.bot.model.message.flex.unit.FlexMarginSize;

import java.util.function.Supplier;

import static java.util.Arrays.asList;

public class MenuMhuYol implements Supplier<FlexMessage> {
        @Override
        public FlexMessage get() {
            final Image heroBlock = createHeroBlock();  //ภาพหัว
            final Box bodyBlock = createBodyBlock();    //detail
            final Box footerBlock = createFooterBox();  //ส่วนไปต่อ ขั้นตอนการทำ
    
            final Bubble bubble = Bubble.builder()
                    .hero(heroBlock)            
                    .body(bodyBlock)
                    .footer(footerBlock)
                    .build();
            return new FlexMessage("Meung Menu", bubble);
        }
    
        private Image createHeroBlock() {
            return Image.builder()
                    .url("https://d3h1lg3ksw6i6b.cloudfront.net/media/image/2019/06/05/8af8a6431722405e8bb6bd85841160b7_6.+Moo+Yor+Credit+photo+Huen+Lamphun.jpg")  // ใส่รูปเมนู
                    .size(Image.ImageSize.FULL_WIDTH)
                    .aspectRatio(Image.ImageAspectRatio.R20TO13)
                    .aspectMode(Image.ImageAspectMode.Cover)
                    .action(new URIAction("label", "https://d3h1lg3ksw6i6b.cloudfront.net/media/image/2019/06/05/8af8a6431722405e8bb6bd85841160b7_6.+Moo+Yor+Credit+photo+Huen+Lamphun.jpg"))  // ใส่รูปเมนู
                    .build();
        }
    
        private Box createBodyBlock() {
            final Text title = Text.builder()
                    .text("หมูยอ")                     // ชื่อเมนู
                    .weight(Text.TextWeight.BOLD)
                    .size(FlexFontSize.XL)
                    .build();
            final Box menus = createMenusBox();
            final Box recipe = createRecipeBox();
            final Box direct = createDirectBox();
    
            return Box.builder()
                    .layout(FlexLayout.VERTICAL)
                    .spacing(FlexMarginSize.MD)
                    .contents(asList(title, menus, recipe, direct))
                    .build();
        }
    
        private Box createRecipeBox() {
            final Box recipe = Box.builder()
                    .layout(FlexLayout.BASELINE)
                    .spacing(FlexMarginSize.XS)
                    .contents(asList(
                            Text.builder()
                                    .text("อยากจะกิน “หมูยอ” ไส้กรอกหมูสีอ่อน") // เกริ่นเมนู
                                    .size(FlexFontSize.XS)
                                    .color("#aaaaaa")
                                    .flex(1)
                                    .build())).build();
            return recipe;
        }
    
        private Box createDirectBox() {
            final Box direct = Box.builder()
                    .layout(FlexLayout.BASELINE)
                    .spacing(FlexMarginSize.XS)
                    .contents(asList(
                            Text.builder()
                                    .text("วันนี้เราขอเสนอสูตร “หมูยอ” กินหมูยอเสร็จมา ยอ หนูได้นะคะ ") // คำคม/คำแนะนำ
                                    .size(FlexFontSize.XS)
                                    .color("#aaaaaa")
                                    .flex(1)
                                    .build())).build();
            return direct;
        }
    
        private Box createMenusBox() {
            final Box menu1 = Box.builder()
                    .layout(FlexLayout.BASELINE)
                    .contents(asList(
                            Icon.builder()
                                    .url("https://cdn-icons-png.flaticon.com/512/45/45332.png").build(),   // icon
                            Text.builder().text("50 Baht")   // Bath
                                    .weight(Text.TextWeight.BOLD)
                                    .margin(FlexMarginSize.SM)
                                    .flex(0)
                                    .build(),
                            Text.builder().text("350 kcl")    // แคลลอรี่
                                    .size(FlexFontSize.SM)
                                    .align(FlexAlign.END)
                                    .color("#aaaaaa")
                                    .build()
    
                    ))
                    .build();
            return Box.builder()
                    .layout(FlexLayout.VERTICAL)
                    .spacing(FlexMarginSize.SM)
                    .contents(asList(menu1)) // .contents(asList(menu1, menu2)) ตัวจริง ถ้า มี menu 2
                    .build();
        }
    
        private Box createFooterBox() {
            final Spacer spacer = Spacer.builder().size(FlexMarginSize.XXL).build();
            final Button button = Button.builder()
                    .style(Button.ButtonStyle.PRIMARY)
                    .color("#905c44")
                    .action(new URIAction("แตะที่นี่ เพื่อดูขั้นตอนวิธีการทำ", "https://www.loseweightth.com/%e0%b8%a2%e0%b8%b3%e0%b8%ab%e0%b8%a1%e0%b8%b9%e0%b8%a2%e0%b8%ad/%e0%b8%a7%e0%b8%b4%e0%b8%98%e0%b8%b5%e0%b8%97%e0%b8%b3%e0%b8%a2%e0%b8%b3%e0%b8%ab%e0%b8%a1%e0%b8%b9%e0%b8%a2%e0%b8%ad/"))   // ขั้นตอนการทำ
                    .build();
            return Box.builder()
                    .layout(FlexLayout.VERTICAL)
                    .contents(asList(spacer, button))
                    .build();
        }
}