package com.yuthapumworkshop2.linebot;

import com.linecorp.bot.model.action.URIAction;
import com.linecorp.bot.model.message.FlexMessage;
import com.linecorp.bot.model.message.flex.component.*;
import com.linecorp.bot.model.message.flex.container.Bubble;
import com.linecorp.bot.model.message.flex.unit.FlexAlign;
import com.linecorp.bot.model.message.flex.unit.FlexFontSize;
import com.linecorp.bot.model.message.flex.unit.FlexLayout;
import com.linecorp.bot.model.message.flex.unit.FlexMarginSize;

import java.util.function.Supplier;

import static java.util.Arrays.asList;

public class MenuGaangOmm implements Supplier<FlexMessage> {
        @Override
        public FlexMessage get() {
            final Image heroBlock = createHeroBlock();  //ภาพหัว
            final Box bodyBlock = createBodyBlock();    //detail
            final Box footerBlock = createFooterBox();  //ส่วนไปต่อ ขั้นตอนการทำ
    
            final Bubble bubble = Bubble.builder()
                    .hero(heroBlock)            
                    .body(bodyBlock)
                    .footer(footerBlock)
                    .build();
            return new FlexMessage("Meung Menu", bubble);
        }
    
        private Image createHeroBlock() {
            return Image.builder()
                    .url("https://www.lovethailand.org/thumb.php?x=300&y=300&src=images/banner/content/lovethailand_banner_20202207050317.jpg")  // ใส่รูปเมนู
                    .size(Image.ImageSize.FULL_WIDTH)
                    .aspectRatio(Image.ImageAspectRatio.R20TO13)
                    .aspectMode(Image.ImageAspectMode.Cover)
                    .action(new URIAction("label", "https://www.lovethailand.org/thumb.php?x=300&y=300&src=images/banner/content/lovethailand_banner_20202207050317.jpg"))  // ใส่รูปเมนู
                    .build();
        }
    
        private Box createBodyBlock() {
            final Text title = Text.builder()
                    .text("แกงอ่อมเนื้อ")                     // ชื่อเมนู
                    .weight(Text.TextWeight.BOLD)
                    .size(FlexFontSize.XL)
                    .build();
            final Box menus = createMenusBox();
            final Box recipe = createRecipeBox();
            final Box direct = createDirectBox();
    
            return Box.builder()
                    .layout(FlexLayout.VERTICAL)
                    .spacing(FlexMarginSize.MD)
                    .contents(asList(title, menus, recipe, direct))
                    .build();
        }
    
        private Box createRecipeBox() {
            final Box recipe = Box.builder()
                    .layout(FlexLayout.BASELINE)
                    .spacing(FlexMarginSize.XS)
                    .contents(asList(
                            Text.builder()
                                    .text("นิยมใช้เนื้อน่องลาย - เนื้อสามชั้น") // เกริ่นเมนู
                                    .size(FlexFontSize.XS)
                                    .color("#aaaaaa")
                                    .flex(1)
                                    .build())).build();
            return recipe;
        }
    
        private Box createDirectBox() {
            final Box direct = Box.builder()
                    .layout(FlexLayout.BASELINE)
                    .spacing(FlexMarginSize.XS)
                    .contents(asList(
                            Text.builder()
                                    .text("แกงอ่อม ถือเป็นอาหารชั้นดีอย่างหนึ่งของชาวล้านนา นิยมใช้เลี้ยงแขกในเทศกาลงานเลี้ยงต่าง ๆ") // คำคม/คำแนะนำ
                                    .size(FlexFontSize.XS)
                                    .color("#aaaaaa")
                                    .flex(1)
                                    .build())).build();
            return direct;
        }
    
        private Box createMenusBox() {
            final Box menu1 = Box.builder()
                    .layout(FlexLayout.BASELINE)
                    .contents(asList(
                            Icon.builder()
                                    .url("https://cdn-icons-png.flaticon.com/512/45/45332.png").build(),   // icon
                            Text.builder().text("60 - 80 Baht")   // Bath
                                    .weight(Text.TextWeight.BOLD)
                                    .margin(FlexMarginSize.SM)
                                    .flex(0)
                                    .build(),
                            Text.builder().text("120kcl")    // แคลลอรี่
                                    .size(FlexFontSize.SM)
                                    .align(FlexAlign.END)
                                    .color("#aaaaaa")
                                    .build()
    
                    ))
                    .build();
            return Box.builder()
                    .layout(FlexLayout.VERTICAL)
                    .spacing(FlexMarginSize.SM)
                    .contents(asList(menu1)) // .contents(asList(menu1, menu2)) ตัวจริง ถ้า มี menu 2
                    .build();
        }
    
        private Box createFooterBox() {
            final Spacer spacer = Spacer.builder().size(FlexMarginSize.XXL).build();
            final Button button = Button.builder()
                    .style(Button.ButtonStyle.PRIMARY)
                    .color("#905c44")
                    .action(new URIAction("แตะที่นี่ เพื่อดูขั้นตอนวิธีการทำ", "https://www.thaihealth.or.th/blog/myblog/topic/1138/%E0%B9%80%E0%B8%97%E0%B8%B5%E0%B9%88%E0%B8%A2%E0%B8%A7%E0%B8%81%E0%B8%B1%E0%B8%99%E0%B9%84%E0%B8%AB%E0%B8%A1/2013/%E0%B8%AD%E0%B8%B2%E0%B8%AB%E0%B8%B2%E0%B8%A3%E0%B8%AD%E0%B8%A3%E0%B9%88%E0%B8%AD%E0%B8%A2%E0%B9%80%E0%B8%AB%E0%B8%B2%E0%B8%B0/34273/%E0%B9%81%E0%B8%81%E0%B8%87%E0%B8%AD%E0%B9%88%E0%B8%AD%E0%B8%A1%20%E0%B8%AD%E0%B8%B2%E0%B8%AB%E0%B8%B2%E0%B8%A3%E0%B9%80%E0%B8%AB%E0%B8%99%E0%B8%B7%E0%B8%AD/"))   // ขั้นตอนการทำ
                    .build();
            return Box.builder()
                    .layout(FlexLayout.VERTICAL)
                    .contents(asList(spacer, button))
                    .build();
    }
}
