package com.yuthapumworkshop2.linebot;

import com.linecorp.bot.client.LineMessagingClient;
import com.linecorp.bot.model.ReplyMessage;
import com.linecorp.bot.model.event.Event;
import com.linecorp.bot.model.event.MessageEvent;
import com.linecorp.bot.model.event.message.TextMessageContent;
import com.linecorp.bot.model.message.*;
import com.linecorp.bot.model.response.BotApiResponse;
import com.linecorp.bot.spring.boot.annotation.EventMapping;
import com.linecorp.bot.spring.boot.annotation.LineMessageHandler;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

@Slf4j
@LineMessageHandler
public class LineBotController {
    @Autowired
    private LineMessagingClient lineMessagingClient;

    @EventMapping
    public void handleTextMessageEvent(MessageEvent<TextMessageContent> event) throws IOException {
        log.info(event.toString());
        TextMessageContent message = event.getMessage();
        handleTextContent(event.getReplyToken(), event, event.getMessage());
    }

    // flex
    private void handleTextContent(String token, Event event, TextMessageContent content) throws IOException {
        String text = content.getText();
        String userId = event.getSource().getUserId();
        
        log.info("Got text message from {} : {} ", token, text );
        switch (text) {
            case "วิธี": {
                break;
            }
            case "แนะนำเมนู": {
                    
                this.reply(token, Arrays.asList(
                    new TextMessage("สวัสดีเจ้า คุณสามารถให้ทางเราแนะนำเมนูได้โดยเลือกตามแบบที่ต้องการดังนี้"+" \n"+">> 'เมนูดีต่อสุขภาพ'\n"+">> 'เมนูเส้น'\n"+">> 'เมนูทำง่ายสะดวก'\n"+">> 'เมนูแกง'\n"+">> 'รวมน้ำพริก'\n"+">> 'ของหวาน'"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "เมนูดีต่อสุขภาพ": {
                    
                this.reply(token, Arrays.asList(
                    new TextMessage("เราขอแนะนำเมนูดีต่อสุขภาพ\n"+" \n"+"'น้ำพริกหนุ่มกับแคบหมู'\n"+"'ไส้อั่ว'\n"+"'แกงโฮะ'"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "เมนูเส้น": {
                    
                this.reply(token, Arrays.asList(
                    new TextMessage("เราขอแนะนำเมนูเส้น\n"+" \n"+"'ขนมจีนน้ำเงี้ยว'\n"+"'ข้าวซอยไก่'\n"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "เมนูทำง่ายสะดวก": {
                    
                this.reply(token, Arrays.asList(
                    new TextMessage("เราขอแนะนำเมนูทำง่ายสะดวก\n"+" \n"+"'ไข่ป่าม'\n"+"'ข้าวหลาม'\n"+"'กระบอง'\n"+"'อ่องปูนา'\n"+"'หมูยอ'"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "เมนูแกง": {
                    
                this.reply(token, Arrays.asList(
                    new TextMessage("เราขอแนะนำเมนูแกง\n"+"'แกงอ่อม'\n"+"'แกงฮังเล'"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "รวมน้ำพริก": {
                    
                this.reply(token, Arrays.asList(
                    new TextMessage("เราขอแนะนำเมนูรวมน้ำพริก\n"+" \n"+"'น้ำพริกหนุ่มกับแคบหมู'\n"+"'น้ำพริกอ่อง'"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "ของหวาน": {
                    
                this.reply(token, Arrays.asList(
                    new TextMessage("เราขอแนะนำเมนูของหวาน\n"+" \n"+"'ขนมฟักทอง'\n"+"'ขนมตาล'"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "อาหารเมืองยอดฮิต": {
                                
                this.reply(token, Arrays.asList(
                    new TextMessage("เราขอแนะนำเมนูอาหารเมืองยอดฮิต\n"+" \n"+">> ลาบดิบ <<\n"+">> ข้าวซอยไก่ <<\n"+">> ขนมจีนน้ำเงี้ยว <<"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "10 อาหารเมืองยอดฮิต": {
                    
                this.reply(token, Arrays.asList(
                    new TextMessage("สวัสดีเจ้า นี่คือ 10 เมนูอาหารเมืองที่ทางเราอยากแนะนำ\n"+"- ลาบดิบ\n"+"- น้ำพริกหนุ่มกับแคบหมู\n"+"- กระบอง\n"+"- ข้าวหลาม\n"+"- ข้าวซอยไก่\n"+"- ไส้อั่ว\n"+"- ขนมจีนน้ำเงี้ยว\n"+"- แกงฮังเล\n"+"- หมูยอ\n"+"- แกงโฮะ"),
                    new TextMessage("คุณสามารถพิมพ์ชื่อเมนูที่ต้องการ เพื่อดูข้อมูลเพิ่มเติม")));
            }
            case "ลาบดิบ": {
                    
                this.reply(token, new MenuLabM().get());
                break;
            }
            case "แกงอ่อมเนื้อ": {
                    
                this.reply(token, new MenuGaangOmm().get());
                break;
            }
            case "ข้าวซอยไก่": {
                    
                this.reply(token, new MenuKaoSoiKai().get());
                break;
            }
            case "ขนมจีนน้ำเงี้ยว": {
                    
                this.reply(token, new MenuKhanomJeenNamNgeo().get());
                break;
            }
            case "กระบอง": {
                    
                this.reply(token, new MenuKraBong().get());
                break;
            }
            case "ขนมฟักทอง": {
                    
                this.reply(token, new MenuKanomfugtong().get());
                break;
            }
            case "ข้าวหลาม": {
                    
                this.reply(token, new MenuKaouLam().get());
                break;
            }
            case "ไข่ป่าม": {
                    
                this.reply(token, new MenuKhaiPam().get());
                break;
            }
            case "น้ำพริกหนุ่มกับแคบหมู": {
                    
                this.reply(token, new MenuNamPigNumAndKhapMhu().get());
                break;
            }
            case "ไส้อั่ว": {
                    
                this.reply(token, new MenuSaiAua().get());
                break;
            }
            case "หมูยอ": {
                    
                this.reply(token, new MenuMhuYol().get());
                break;
            }
            case "อ่องปูนา": {
                    
                this.reply(token, new MenuOngPuna().get());
                break;
            }
            case "แกงฮังเล": {
                    
                this.reply(token, new MenuKangHunLa().get());
                break;
            }
            case "แกงโฮะ": {
                    
                this.reply(token, new MenuKangHo().get());
                break;
            }
            case "น้ำพริกอ่อง": {
                    
                this.reply(token, new MenuNamPrigong().get());
                break;
            }
            case "ขนมตาล": {
                    
                this.reply(token, new MenuKanomTal().get());
                break;
            }
            default:
                this.reply(token, Arrays.asList(
                    new TextMessage("สวัสดีเจ้า คุณสามารถพิมพ์ ' วิธี ' เพื่อคุยโต้ตอบกับทางเรา")));
                                                                            
        }
    }                          

    // reply
    private void replyText(@NonNull String replyToken, @NonNull String message) {
        if(replyToken.isEmpty()) {
            throw new IllegalArgumentException("replyToken is not empty");
        }

        if(message.length() > 1000) {
            message = message.substring(0, 1000 - 2) + "...";
        }
        this.reply(replyToken, new TextMessage(message));
    }

    private void reply(@NonNull String replyToken, @NonNull Message message) {
        reply(replyToken, Collections.singletonList(message));
    }

    private void reply(@NonNull String replyToken, @NonNull List<Message> messages) {
        try {
            BotApiResponse response = lineMessagingClient.replyMessage(
                    new ReplyMessage(replyToken, messages)
            ).get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }


}
